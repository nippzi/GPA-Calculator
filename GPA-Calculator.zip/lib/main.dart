import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'GPA Calculator',
      theme: ThemeData(
        primarySwatch: Colors.purple,
      ),
      home: CourseInputScreen(),
    );
  }
}

// Screen to enter course details (name, grade, credit)
class CourseInputScreen extends StatefulWidget {
  @override
  _CourseInputScreenState createState() => _CourseInputScreenState();
}

class _CourseInputScreenState extends State<CourseInputScreen> {
  List<TextEditingController> subjectControllers = [];
  List<TextEditingController> gradeControllers = [];
  List<TextEditingController> creditControllers = [];
  int numberOfCourses = 1; // Starting with one course

  @override
  void initState() {
    super.initState();
    _initializeControllers();
  }

  // Function to initialize controllers
  void _initializeControllers() {
    subjectControllers =
        List.generate(numberOfCourses, (index) => TextEditingController());
    gradeControllers =
        List.generate(numberOfCourses, (index) => TextEditingController());
    creditControllers =
        List.generate(numberOfCourses, (index) => TextEditingController());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Enter Course Details')),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Dynamic Course Input Fields
            for (int i = 0; i < numberOfCourses; i++) ...[
              Padding(
                padding: const EdgeInsets.only(bottom: 16.0),
                child: Container(
                  padding: EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.purple.shade50,
                    borderRadius: BorderRadius.circular(20), // Corner radius 20
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Course ${i + 1}',
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 20)),
                      SizedBox(height: 10),
                      // Grade and Credit input fields
                      Row(
                        children: [
                          Expanded(
                            child: _buildTextField(
                                gradeControllers[i], 'Enter Grade ${i + 1}'),
                          ),
                          SizedBox(width: 10),
                          Expanded(
                            child: _buildTextField(
                                creditControllers[i], 'Enter Credit ${i + 1}',
                                isNumeric: true),
                          ),
                        ],
                      ),
                      SizedBox(height: 10),
                      // Course Name input field
                      _buildTextField(
                          subjectControllers[i], 'Course Name ${i + 1}'),
                    ],
                  ),
                ),
              ),
            ],

            // Add Course Button
            Center(
              child: ElevatedButton(
                onPressed: () {
                  setState(() {
                    numberOfCourses++;
                    _initializeControllers(); // Reinitialize controllers to add more courses
                  });
                },
                child: Text('Add Another Course'),
                style: ElevatedButton.styleFrom(
                  backgroundColor:
                      Colors.purple.shade100, // Updated to 'backgroundColor'
                  padding: EdgeInsets.symmetric(vertical: 15, horizontal: 30),
                  textStyle: TextStyle(fontSize: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
              ),
            ),

            SizedBox(height: 20),

            // Calculate GPA Button
            Center(
              child: ElevatedButton(
                onPressed: () {
                  List<String> courseNames = [];
                  List<double> grades = [];
                  List<int> credits = [];

                  for (int i = 0; i < numberOfCourses; i++) {
                    if (subjectControllers[i].text.isNotEmpty &&
                        gradeControllers[i].text.isNotEmpty &&
                        creditControllers[i].text.isNotEmpty) {
                      courseNames.add(subjectControllers[i].text);
                      grades.add(getGradePoint(gradeControllers[i].text));
                      credits.add(int.parse(creditControllers[i].text));
                    }
                  }

                  double gpa = calculateGPA(grades, credits);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => GPADisplayScreen(gpa: gpa),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor:
                      Color(0xfffcfafd), // Updated to 'backgroundColor'
                  padding: EdgeInsets.symmetric(vertical: 15, horizontal: 30),
                  textStyle: TextStyle(fontSize: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
                child: Text('Calculate GPA'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Function to build text fields
  Widget _buildTextField(TextEditingController controller, String label,
      {bool isNumeric = false}) {
    return TextField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20),
          borderSide: BorderSide.none,
        ),
        filled: true,
        fillColor: Colors.white,
      ),
      keyboardType: isNumeric ? TextInputType.number : TextInputType.text,
    );
  }

  // Function to convert grade to GPA points
  double getGradePoint(String grade) {
    switch (grade.toUpperCase()) {
      case 'A+':
        return 4.0;
      case 'A':
        return 4.0;
      case 'A-':
        return 3.7;
      case 'B+':
        return 3.3;
      case 'B':
        return 3.0;
      case 'B-':
        return 2.7;
      case 'C+':
        return 2.3;
      case 'C':
        return 2.0;
      case 'C-':
        return 1.7;
      case 'D+':
        return 1.3;
      case 'D':
        return 1.0;
      case 'E':
        return 0.7;
      default:
        return 0.0;
    }
  }

  // GPA Calculation Function
  double calculateGPA(List<double> grades, List<int> credits) {
    double totalPoints = 0;
    int totalCredits = 0;

    for (int i = 0; i < grades.length; i++) {
      totalPoints += grades[i] * credits[i];
      totalCredits += credits[i];
    }

    return totalCredits > 0 ? totalPoints / totalCredits : 0.0;
  }
}

// Screen to display the GPA result
class GPADisplayScreen extends StatelessWidget {
  final double gpa;

  GPADisplayScreen({required this.gpa});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Your GPA')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Your GPA is:',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              Text(
                gpa.toStringAsFixed(2),
                style: TextStyle(
                    fontSize: 40,
                    fontWeight: FontWeight.bold,
                    color: Colors.purple),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: Text('Go Back'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
