package com.example.dart_code

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
